function run_smad(ref_filename, dis_filename, width, height)

path(path,'./STMAD_2011_MatlabCode');

calcSMADScore(ref_filename, dis_filename, width, height);

% dmos_score = rred2dmos(strred_score)

end
























