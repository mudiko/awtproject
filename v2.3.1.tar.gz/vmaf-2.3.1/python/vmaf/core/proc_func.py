__copyright__ = "Copyright 2016-2020, Netflix, Inc."
__license__ = "BSD+Patent"

proc_func_dict = {
    'identity': lambda x: x,
    'multiply': lambda x: x * 1.1,
}
